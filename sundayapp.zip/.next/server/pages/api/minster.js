(function() {
var exports = {};
exports.id = 693;
exports.ids = [693];
exports.modules = {

/***/ 4047:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": function() { return /* binding */ handler; }
});

;// CONCATENATED MODULE: external "mongodb"
var external_mongodb_namespaceObject = require("mongodb");;
;// CONCATENATED MODULE: ./pages/api/minster.ts
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

// Next.js API route support: https://nextjs.org/docs/api-routes/introduction


const omit_id = arrangement => {
  delete arrangement._id;
  return arrangement;
};

async function getArrangements(req, res, mongodbClient) {
  let {
    startDate,
    endDate,
    dates
  } = req.query;
  let datequerystring = dates;

  if (!startDate && !datequerystring) {
    return res.status(400).end();
  }

  if (!endDate) {
    endDate = startDate;
  }

  const database = mongodbClient.db('worship');
  const arrangements = database.collection('serving_staff_arrangements');
  let result = [];

  if (startDate) {
    result = await arrangements.find({
      riqi: {
        $gte: startDate,
        $lte: endDate
      }
    }, {
      sort: {
        riqi: 1
      }
    }).toArray();
  } else {
    for (let date of datequerystring.split(',')) {
      let dateArrange = await arrangements.findOne({
        riqi: date
      });

      if (!dateArrange) {
        dateArrange = {
          riqi: date
        };
      }

      result.push(dateArrange);
    }
  }

  result = result.map(omit_id);
  res.status(200).json(result);
}

async function setArrangements(req, res, mongodbClient) {
  const database = mongodbClient.db('worship');
  const arrangements = database.collection('serving_staff_arrangements');
  const promises = req.body.map(arrangement => _objectSpread(_objectSpread({}, arrangement), {}, {
    _id: arrangement.riqi
  })).map(arrangement => arrangements.findOneAndReplace({
    "riqi": arrangement.riqi
  }, arrangement, {
    upsert: true
  }));

  try {
    await Promise.all(promises);
    res.status(200).end();
  } catch (err) {
    console.log("update arrangements failure", err);
    res.status(500).end();
  }
}

const MongodbConnect = async (callback, req, res) => {
  const client = new external_mongodb_namespaceObject.MongoClient(process.env.MONGODB_URL);

  try {
    await client.connect();
    await callback(req, res, client);
  } catch (err) {
    console.log("monogo db connect error", err);
    res.status(500).end();
  } finally {
    client.close();
  }
};

async function handler(req, res) {
  const {
    method
  } = req;

  switch (method) {
    case 'GET':
      return await MongodbConnect(getArrangements, req, res);

    case 'POST':
      return await MongodbConnect(setArrangements, req, res);

    default:
      res.setHeader('Allow', ['GET', 'PUT']);
      res.status(405).end(`Method ${method} Not Allowed`);
  }
}

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = function(moduleId) { return __webpack_require__(__webpack_require__.s = moduleId); }
var __webpack_exports__ = (__webpack_exec__(4047));
module.exports = __webpack_exports__;

})();