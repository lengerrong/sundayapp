exports.id = 67;
exports.ids = [67];
exports.modules = {

/***/ 3067:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": function() { return /* binding */ bible_scriptures_selector; }
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(5282);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(9297);
// EXTERNAL MODULE: external "mobx-react-lite"
var external_mobx_react_lite_ = __webpack_require__(4912);
// EXTERNAL MODULE: ./node_modules/@material-ui/core/esm/styles/makeStyles.js
var makeStyles = __webpack_require__(1120);
// EXTERNAL MODULE: ./node_modules/@material-ui/core/esm/styles/createStyles.js
var createStyles = __webpack_require__(5117);
// EXTERNAL MODULE: ./node_modules/@material-ui/core/esm/Button/Button.js
var Button = __webpack_require__(282);
// EXTERNAL MODULE: external "@material-ui/core"
var core_ = __webpack_require__(1731);
// EXTERNAL MODULE: ./node_modules/@material-ui/core/esm/ListItemText/ListItemText.js
var ListItemText = __webpack_require__(5757);
// EXTERNAL MODULE: ./node_modules/@material-ui/core/esm/ListItemSecondaryAction/ListItemSecondaryAction.js
var ListItemSecondaryAction = __webpack_require__(1860);
// EXTERNAL MODULE: ./node_modules/@material-ui/core/esm/Checkbox/Checkbox.js + 4 modules
var Checkbox = __webpack_require__(6653);
// EXTERNAL MODULE: ./node_modules/@material-ui/core/esm/Paper/Paper.js
var Paper = __webpack_require__(9895);
// EXTERNAL MODULE: ./node_modules/@material-ui/core/esm/Grid/Grid.js
var Grid = __webpack_require__(1749);
// EXTERNAL MODULE: ./node_modules/@material-ui/core/esm/Slide/Slide.js
var Slide = __webpack_require__(2285);
;// CONCATENATED MODULE: ./components/bible.volume.chatper.selector.tsx




function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }










const cnvs = __webpack_require__(4858);

const useStyles = (0,makeStyles/* default */.Z)(theme => (0,createStyles/* default */.Z)({
  root: {
    flexGrow: 1
  },
  volumnCard: {
    border: 'thick double #32a1ce',
    minWidth: '100px',
    minHeight: '120px'
  },
  chapterCard: {
    border: 'thick double #32a1ce',
    minWidth: '40px',
    minHeight: '40px'
  },
  focusVolumnCard: {
    border: 'thick double red',
    color: 'red',
    minWidth: '100px',
    minHeight: '120px'
  }
}));
var ViewType;

(function (ViewType) {
  ViewType[ViewType["GRID"] = 0] = "GRID";
  ViewType[ViewType["LIST"] = 1] = "LIST";
})(ViewType || (ViewType = {}));

var ContentType;

(function (ContentType) {
  ContentType[ContentType["VOLUMN"] = 0] = "VOLUMN";
  ContentType[ContentType["CHAPTER"] = 1] = "CHAPTER";
})(ContentType || (ContentType = {}));

function Volumns({
  currentBook,
  onVolumnClick
}) {
  const classes = useStyles();

  const renderBookList = booksList => {
    return /*#__PURE__*/jsx_runtime_.jsx(jsx_runtime_.Fragment, {
      children: booksList.map(book => {
        return /*#__PURE__*/jsx_runtime_.jsx(Grid/* default */.Z, {
          item: true,
          xs: 3,
          onClick: () => onVolumnClick(book),
          children: /*#__PURE__*/jsx_runtime_.jsx(core_.Card, {
            className: book.bookName === currentBook.bookName ? classes.focusVolumnCard : classes.volumnCard,
            children: /*#__PURE__*/(0,jsx_runtime_.jsxs)(core_.CardContent, {
              children: [/*#__PURE__*/jsx_runtime_.jsx(core_.Typography, {
                children: book.bookAbbrName
              }), /*#__PURE__*/jsx_runtime_.jsx(core_.Typography, {
                children: book.bookName
              })]
            })
          })
        }, book.bookName);
      })
    });
  };

  return /*#__PURE__*/(0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
    children: [/*#__PURE__*/jsx_runtime_.jsx(core_.Typography, {
      variant: "h3",
      component: "h3",
      children: "\u65E7\u7EA6"
    }), /*#__PURE__*/jsx_runtime_.jsx(Grid/* default */.Z, {
      container: true,
      children: renderBookList(cnvs.data[0].booksList)
    }), /*#__PURE__*/jsx_runtime_.jsx(core_.Typography, {
      variant: "h3",
      component: "h3",
      children: "\u65B0\u7EA6"
    }), /*#__PURE__*/jsx_runtime_.jsx(Grid/* default */.Z, {
      container: true,
      children: renderBookList(cnvs.data[1].booksList)
    })]
  });
}

const range = (start, stop, step) => Array.from({
  length: (stop - start) / step + 1
}, (_, i) => start + i * step);

function Chapters({
  book,
  onChapterClick
}) {
  const classes = useStyles();
  return /*#__PURE__*/jsx_runtime_.jsx(Grid/* default */.Z, {
    container: true,
    children: range(1, book.bookChapterMaxNumber, 1).map(index => {
      return /*#__PURE__*/jsx_runtime_.jsx(Grid/* default */.Z, {
        item: true,
        xs: 2,
        onClick: () => onChapterClick(index),
        children: /*#__PURE__*/jsx_runtime_.jsx(core_.Card, {
          className: classes.chapterCard,
          children: /*#__PURE__*/jsx_runtime_.jsx(core_.CardContent, {
            children: /*#__PURE__*/jsx_runtime_.jsx(core_.Typography, {
              children: index
            })
          })
        })
      }, index);
    })
  });
}

const genBook = {
  "versionCode": "cnvs",
  "bookId": 1,
  "bookUsfm": "GEN",
  "canon": "ot",
  "bookName": "创世记",
  "bookAbbrName": "创",
  "bookChapterMaxNumber": 50,
  "versesCount": 0
};
const BibleVolumeChapterSelector = (0,external_mobx_react_lite_.observer)(({
  onVolumeChapterSelected
}) => {
  const classes = useStyles();
  const local = (0,external_mobx_react_lite_.useLocalObservable)(() => ({
    viewType: ViewType.GRID,
    // grid view
    contentType: ContentType.VOLUMN,
    book: genBook,

    setViewType(viewType) {
      this.viewType = viewType;
    },

    setContentType(contentType) {
      this.contentType = contentType;
    },

    setBook(book) {
      this.book = book;
    }

  }));

  const onVolumnClicked = () => {
    local.setContentType(ContentType.VOLUMN);
  };

  const onChapterClicked = () => {
    local.setContentType(ContentType.CHAPTER);
  };

  const getTitle = () => {
    if (local.contentType === ContentType.CHAPTER) {
      return local.book.bookName;
    } else {
      return '圣经目录';
    }
  };

  const onChapterClick = bookChapterIndex => {
    onVolumeChapterSelected && onVolumeChapterSelected(_objectSpread(_objectSpread({}, local.book), {}, {
      bookChapterIndex
    }));
  };

  const onVolumnClick = book => {
    local.setBook(book);
    local.setContentType(ContentType.CHAPTER);
  };

  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
    className: classes.root,
    children: [/*#__PURE__*/jsx_runtime_.jsx(Grid/* default */.Z, {
      container: true,
      direction: "row",
      justifyContent: "center",
      alignItems: "center",
      children: getTitle()
    }), /*#__PURE__*/(0,jsx_runtime_.jsxs)(Grid/* default */.Z, {
      container: true,
      direction: "row",
      justifyContent: "space-between",
      alignItems: "center",
      children: [/*#__PURE__*/jsx_runtime_.jsx(Button/* default */.Z, {
        variant: "contained",
        color: local.contentType === ContentType.VOLUMN ? "secondary" : "default",
        onClick: onVolumnClicked,
        children: "\u5377"
      }), /*#__PURE__*/jsx_runtime_.jsx(Button/* default */.Z, {
        variant: "contained",
        color: local.contentType === ContentType.CHAPTER ? "secondary" : "default",
        onClick: onChapterClicked,
        children: "\u7AE0"
      })]
    }), /*#__PURE__*/jsx_runtime_.jsx(Slide/* default */.Z, {
      direction: "left",
      in: local.contentType === ContentType.VOLUMN,
      mountOnEnter: true,
      unmountOnExit: true,
      children: /*#__PURE__*/jsx_runtime_.jsx(Paper/* default */.Z, {
        children: /*#__PURE__*/jsx_runtime_.jsx(Volumns, {
          currentBook: local.book,
          onVolumnClick: onVolumnClick
        })
      })
    }), /*#__PURE__*/jsx_runtime_.jsx(Slide/* default */.Z, {
      direction: "right",
      in: local.contentType === ContentType.CHAPTER,
      mountOnEnter: true,
      unmountOnExit: true,
      children: /*#__PURE__*/jsx_runtime_.jsx(Paper/* default */.Z, {
        children: /*#__PURE__*/jsx_runtime_.jsx(Chapters, {
          book: local.book,
          onChapterClick: onChapterClick
        })
      })
    })]
  });
});
/* harmony default export */ var bible_volume_chatper_selector = (BibleVolumeChapterSelector);
;// CONCATENATED MODULE: ./components/bible.scriptures.selector.tsx












const bible_scriptures_selector_useStyles = (0,makeStyles/* default */.Z)(theme => (0,createStyles/* default */.Z)({
  root: {
    flexGrow: 1
  },
  selectingRoot: {
    borderRadius: '4px',
    background: 'linear-gradient(45deg, #2196F3 30%, #21CBF3 90%)',
    border: 0,
    color: 'white',
    boxShadow: '0 3px 5px 2px rgba(255, 105, 135, .3)'
  },
  scripture: {
    color: 'indigo'
  }
}));
const VersesSelector = (0,external_mobx_react_lite_.observer)(({
  book,
  onScritpuresSelected,
  verses
}) => {
  const classes = bible_scriptures_selector_useStyles();
  const local = (0,external_mobx_react_lite_.useLocalObservable)(() => ({
    checked: [],

    setChecked(checked) {
      this.checked = checked;
    }

  }));

  const handleToggle = index => {
    const currentIndex = local.checked.indexOf(index);
    const newChecked = [...local.checked];

    if (currentIndex === -1) {
      newChecked.push(index);
    } else {
      newChecked.splice(currentIndex, 1);
    }

    local.setChecked(newChecked);
  };

  const onOk = () => {
    let selected = Array.from(local.checked);
    selected.sort((a, b) => a - b);
    let selected_verses = selected.map(index => verses[index]);

    if (selected_verses.length <= 0) {
      alert('请至少选择一节经文!');
      return;
    }

    onScritpuresSelected && onScritpuresSelected(book, selected_verses);
  };

  const onCancel = () => {
    local.setChecked([]);
    onScritpuresSelected && onScritpuresSelected(book, []);
  };

  const getLabelId = index => 'checkbok-lablel-' + index;

  return /*#__PURE__*/(0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
    children: [/*#__PURE__*/jsx_runtime_.jsx(core_.List, {
      component: "nav",
      "aria-label": "secondary selecting-scriptures",
      className: classes.selectingRoot,
      children: /*#__PURE__*/(0,jsx_runtime_.jsxs)(core_.ListItem, {
        children: [/*#__PURE__*/jsx_runtime_.jsx(ListItemText/* default */.Z, {
          id: "switch-list-label-selecting",
          primary: "\u9009\u62E9\u7ECF\u6587"
        }), /*#__PURE__*/(0,jsx_runtime_.jsxs)(ListItemSecondaryAction/* default */.Z, {
          children: [/*#__PURE__*/jsx_runtime_.jsx(Button/* default */.Z, {
            variant: "contained",
            color: "secondary",
            onClick: onOk,
            children: "\u786E\u5B9A"
          }), /*#__PURE__*/jsx_runtime_.jsx(Button/* default */.Z, {
            variant: "contained",
            onClick: onCancel,
            children: "\u53D6\u6D88"
          })]
        })]
      })
    }), /*#__PURE__*/jsx_runtime_.jsx(core_.List, {
      component: "nav",
      "aria-label": "secondary scriptures",
      children: verses.map((verse, index) => /*#__PURE__*/(0,jsx_runtime_.jsxs)(core_.ListItem, {
        button: true,
        onClick: () => handleToggle(index),
        children: [/*#__PURE__*/jsx_runtime_.jsx(ListItemText/* default */.Z, {
          id: getLabelId(index),
          primary: verse,
          classes: {
            primary: classes.scripture
          }
        }), /*#__PURE__*/jsx_runtime_.jsx(ListItemSecondaryAction/* default */.Z, {
          children: /*#__PURE__*/jsx_runtime_.jsx(Checkbox/* default */.Z, {
            edge: "end",
            onChange: () => handleToggle(index),
            checked: local.checked.indexOf(index) !== -1,
            inputProps: {
              'aria-labelledby': getLabelId(index)
            }
          })
        })]
      }, verse))
    })]
  });
});
const BibleScripturesSelector = (0,external_mobx_react_lite_.observer)(({
  onScritpuresSelected
}) => {
  const classes = bible_scriptures_selector_useStyles();
  const local = (0,external_mobx_react_lite_.useLocalObservable)(() => ({
    book: null,
    // grid view
    verses: null,

    setBook(book) {
      this.book = book;
    },

    setVerses(verses) {
      this.verses = verses;
    }

  }));

  const onVolumeChapterSelected = async book => {
    let scriptures = await fetch('/api/scriptures?search=' + book.bookName + book.bookChapterIndex).then(res => res.json());
    let chapter = scriptures[0];
    local.setVerses(chapter[chapter.search][0]);
    local.setBook(book);
  };

  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
    className: classes.root,
    children: [local.book === null && /*#__PURE__*/jsx_runtime_.jsx(bible_volume_chatper_selector, {
      onVolumeChapterSelected: onVolumeChapterSelected
    }), local.book && /*#__PURE__*/jsx_runtime_.jsx(VersesSelector, {
      book: local.book,
      verses: local.verses,
      onScritpuresSelected: onScritpuresSelected
    })]
  });
});
/* harmony default export */ var bible_scriptures_selector = (BibleScripturesSelector);

/***/ })

};
;