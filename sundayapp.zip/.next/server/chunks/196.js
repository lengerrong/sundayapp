exports.id = 196;
exports.ids = [196];
exports.modules = {

/***/ 3196:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "W4": function() { return /* binding */ getSongLable; },
/* harmony export */   "fj": function() { return /* binding */ getSongTitle; },
/* harmony export */   "tC": function() { return /* binding */ getSongVerseTitle; },
/* harmony export */   "BS": function() { return /* binding */ getSongVerse; },
/* harmony export */   "id": function() { return /* binding */ getSongVerseIndex; },
/* harmony export */   "jT": function() { return /* binding */ staffArrangeTitle; },
/* harmony export */   "Xf": function() { return /* binding */ convertToRoman; },
/* harmony export */   "wi": function() { return /* binding */ getScriptureSectionSubTitle; },
/* harmony export */   "nq": function() { return /* binding */ getScriptureSectionTitle; },
/* harmony export */   "AN": function() { return /* binding */ getScriptureSectionsTitle; },
/* harmony export */   "Rl": function() { return /* binding */ getScriptureSectionText; },
/* harmony export */   "XQ": function() { return /* binding */ getScriptureSectionGoldenText; },
/* harmony export */   "Sk": function() { return /* binding */ getChunksPath; }
/* harmony export */ });
function getSongLable(song) {
  return (song.type == 0 ? '诗篇' : '圣诗') + song.index + ': 第' + song.verses.map(verse => verse.index).join(',') + '节';
}
function getSongTitle(song) {
  return (song.type == 0 ? '诗篇' : '圣诗') + song.index;
}
function getSongVerseTitle(song, index) {
  if (song.verses[index].subtitle) return song.verses[index].subtitle;
  return song.title ? song.title : '';
}
function getSongVerse(song, index) {
  return song.verses[index].text;
}
function getSongVerseIndex(song, index) {
  return song.verses[index].index;
}
function staffArrangeTitle(arrangements) {
  let months = new Set(arrangements.map(arrange => arrange.riqi && Number(arrange.riqi.substring(5, 7))));
  return Array.from(months).join('、');
}
const romanMatrix = [[1000, 'M'], [900, 'CM'], [500, 'D'], [400, 'CD'], [100, 'C'], [90, 'XC'], [50, 'L'], [40, 'XL'], [10, 'X'], [9, 'IX'], [5, 'V'], [4, 'IV'], [1, 'I']];
function convertToRoman(num) {
  if (num === 0) {
    return '';
  }

  for (let i = 0; i < romanMatrix.length; i++) {
    if (num >= romanMatrix[i][0]) {
      return romanMatrix[i][1] + convertToRoman(num - romanMatrix[i][0]);
    }
  }

  return '';
}

function indexsToString(indexs) {
  let result = null;
  let stack = [];

  for (let index of indexs) {
    if (stack.length == 0) {
      stack.push(index);
    } else if (stack.length == 1) {
      if (index == stack[0] + 1) {
        stack.push(index);
      } else {
        result = result ? result + ',' + stack[0] : '' + stack[0];
        stack[0] = index;
      }
    } else {
      if (index == stack[1] + 1) {
        stack[1] = index;
      } else {
        result = result ? result + ',' + stack[0] + '-' + stack[1] : stack[0] + '-' + stack[1];
        stack = [];
        stack.push(index);
      }
    }
  }

  if (stack.length == 1) {
    result = result ? result + ',' + stack[0] : '' + stack[0];
  } else if (stack.length == 2) {
    result = result ? result + ',' + stack[0] + '-' + stack[1] : stack[0] + '-' + stack[1];
  }

  return result ? result : '';
}

function getVersesIndexString(verses) {
  let indexs = verses.map(s => {
    let m = s.match(/^\d+/);

    if (m) {
      return Number(m[0]);
    } else {
      return -1;
    }
  }).filter(i => i != -1);
  return indexsToString(indexs);
}

function getScriptureSectionSubTitle(ScriptureSection) {
  if (!ScriptureSection.scriptures) {
    return '';
  }

  return ScriptureSection.scriptures.map(s => {
    return s.chapterIndex.toString() + ':' + getVersesIndexString(s.verses);
  }).join(';');
}
function getScriptureSectionTitle(ScriptureSection) {
  if (!ScriptureSection) {
    return null;
  }

  return ScriptureSection.bookName + getScriptureSectionSubTitle(ScriptureSection);
}
function getScriptureSectionsTitle(ScriptureSections) {
  if (!ScriptureSections) {
    return null;
  }

  return ScriptureSections.map(getScriptureSectionTitle).join('|');
}
function getScriptureSectionText(scritpure) {
  if (!scritpure) {
    return null;
  }

  return scritpure.verses.join('\n');
}
function getScriptureSectionGoldenText(scritpure) {
  if (!scritpure) {
    return '';
  }

  return scritpure.verses.map(v => v.replace(/^\d+/, '')).join('');
}
function getChunksPath() {
  return "production".toLowerCase() === 'production' ? '/../../chunks/' : '/../../';
}

/***/ })

};
;